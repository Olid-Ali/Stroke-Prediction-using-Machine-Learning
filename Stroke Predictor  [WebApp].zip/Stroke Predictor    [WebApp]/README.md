# Stroke-Predictor-app <br>
Machine Learning Approach.

Full Website - https://stroke-prediction-6cm6.onrender.com <br>
(It will take some time to load the full website. Be patient!)
